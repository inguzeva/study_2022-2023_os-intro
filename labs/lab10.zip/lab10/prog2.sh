#!/bin/bash
echo 'Введите любые числа'
read n
for A in $*
do echo $A
done
