#!/bin/bash
tar -cvf ~/backup/backup.tar prog1.sh
